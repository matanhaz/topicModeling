./initialize-project-and-collect-issues.pl -p Io -n commons-io -r https://github.com/apache/commons-io -g jira -t IO -e "/(IO-\d+)/mi" -w bug-mining_87
python ./extractor.py -a bug-mining_87//project_repos//commons-io.git -w bug-mining_87 -b bug-mining_87//framework//projects//Io//active-bugs.csv
./initialize-revisions.pl -p Io -w bug-mining_87 -i 87
./analyze-project.pl -p Io -w bug-mining_87 -g jira -t IO -i 87
./get-trigger.pl -p Io -w bug-mining_87

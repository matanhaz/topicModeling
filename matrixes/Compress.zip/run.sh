./initialize-project-and-collect-issues.pl -p Compress -n commons-compress -r https://github.com/apache/commons-compress -g jira -t COMPRESS -e "/(COMPRESS-\d+)/mi" -w bug-mining_102
python ./extractor.py -a bug-mining_102//project_repos//commons-compress.git -w bug-mining_102 -b bug-mining_102//framework//projects//Compress//active-bugs.csv
./initialize-revisions.pl -p Compress -w bug-mining_102 -i 102
./analyze-project.pl -p Compress -w bug-mining_102 -g jira -t COMPRESS -i 102
./get-trigger.pl -p Compress -w bug-mining_102
./get-metadata.pl -p Compress -w bug-mining_102

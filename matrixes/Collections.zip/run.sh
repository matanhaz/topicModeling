./initialize-project-and-collect-issues.pl -p Collections -n commons-collections -r https://github.com/apache/commons-collections -g jira -t COLLECTIONS -e "/(COLLECTIONS-\d+)/mi" -w bug-mining_7
python ./extractor.py -a bug-mining_7//project_repos//commons-collections.git -w bug-mining_7 -b bug-mining_7//framework//projects//Collections//active-bugs.csv
./initialize-revisions.pl -p Collections -w bug-mining_7 -i 7
./analyze-project.pl -p Collections -w bug-mining_7 -g jira -t COLLECTIONS -i 7
./get-trigger.pl -p Collections -w bug-mining_7

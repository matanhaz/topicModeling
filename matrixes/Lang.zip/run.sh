./initialize-project-and-collect-issues.pl -p Lang -n commons-lang -r https://github.com/apache/commons-lang -g jira -t LANG -e "/(LANG-\d+)/mi" -w bug-mining_90
python ./extractor.py -a bug-mining_90//project_repos//commons-lang.git -w bug-mining_90 -b bug-mining_90//framework//projects//Lang//active-bugs.csv
./initialize-revisions.pl -p Lang -w bug-mining_90 -i 90
./analyze-project.pl -p Lang -w bug-mining_90 -g jira -t LANG -i 90
./get-trigger.pl -p Lang -w bug-mining_90

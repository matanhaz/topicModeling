./initialize-project-and-collect-issues.pl -p Csv -n commons-csv -r https://github.com/apache/commons-csv -g jira -t CSV -e "/(CSV-\d+)/mi" -w bug-mining_40
python ./extractor.py -a bug-mining_40//project_repos//commons-csv.git -w bug-mining_40 -b bug-mining_40//framework//projects//Csv//active-bugs.csv
./initialize-revisions.pl -p Csv -w bug-mining_40 -i 40
./analyze-project.pl -p Csv -w bug-mining_40 -g jira -t CSV -i 40
./get-trigger.pl -p Csv -w bug-mining_40

./initialize-project-and-collect-issues.pl -p Codec -n commons-codec -r https://github.com/apache/commons-codec -g jira -t CODEC -e "/(CODEC-\d+)/mi" -w bug-mining_73
python ./extractor.py -a bug-mining_73//project_repos//commons-codec.git -w bug-mining_73 -b bug-mining_73//framework//projects//Codec//active-bugs.csv
./initialize-revisions.pl -p Codec -w bug-mining_73 -i 73
./analyze-project.pl -p Codec -w bug-mining_73 -g jira -t CODEC -i 73
./get-trigger.pl -p Codec -w bug-mining_73

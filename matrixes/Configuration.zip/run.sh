./initialize-project-and-collect-issues.pl -p Configuration -n commons-configuration -r https://github.com/apache/commons-configuration -g jira -t CONFIGURATION -e "/(CONFIGURATION-\d+)/mi" -w bug-mining_98
python ./extractor.py -a bug-mining_98//project_repos//commons-configuration.git -w bug-mining_98 -b bug-mining_98//framework//projects//Configuration//active-bugs.csv
./initialize-revisions.pl -p Configuration -w bug-mining_98 -i 98
./analyze-project.pl -p Configuration -w bug-mining_98 -g jira -t CONFIGURATION -i 98
./get-trigger.pl -p Configuration -w bug-mining_98
